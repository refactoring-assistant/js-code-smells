class MathLib {
  add(a, b) {
    return a + b;
  }

  subtract(a, b) {
    return a - b;
  }
}