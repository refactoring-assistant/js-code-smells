function createNewUser(firstName, lastName, address, city, state, zip, country, email, username, password, securityQuestion, securityAnswer, agreeToTerms) {
    console.log("Creating a new user with the following details:");
    console.log("Name:", firstName, lastName);
    console.log("Address:", address, city, state, zip, country);
    console.log("Email:", email);
    console.log("Username:", username);
    console.log("Security Question:", securityQuestion);
    console.log("Security Answer:", securityAnswer);
    console.log("Agreed to Terms:", agreeToTerms);
}
