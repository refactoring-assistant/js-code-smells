function updateEmployeeProfile(id, name, age, address, email, phoneNo, department, jobRole, salary, bonus, hireDate) {
    employeeRecords.id = id;
    employeeRecords.name = name;
    employeeRecords.age = age;
    employeeRecords.address = address;
    employeeRecords.email = email;
    employeeRecords.phoneNo = phoneNo;
    employeeRecords.department = department;
    employeeRecords.jobRole = jobRole;
    employeeRecords.salary = salary;
    employeeRecords.bonus = bonus;
    employeeRecords.hireDate = hireDate;
}