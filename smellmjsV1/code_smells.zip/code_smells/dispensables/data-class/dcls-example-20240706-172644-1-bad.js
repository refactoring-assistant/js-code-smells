class CustomerData {
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }
}

const customer = new CustomerData("John Doe", "john@example.com");