function calculateSum(a, b) {
    var sum = a + b;
    var difference = a - b;
    return sum;
}