var x = 10; // Assigning 10 to x
var y = 20; // Assigning 20 to y

// Adding x and y
var sum = x + y; 

// Subtracting x from y
var difference = y - x; 

// Multiplying x and y
var product = x * y; 

// Dividing y by x
var quotient = y / x;