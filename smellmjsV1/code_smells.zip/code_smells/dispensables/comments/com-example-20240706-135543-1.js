// AI Generated Comments Example
// This function calculates the sum of two numbers
function sum(a, b) {
  // First, we add the two parameters together
  let result = a + b;
  
  // Then, we return the result
  return result;
}

// We call the sum function with two numbers (5 and 7) to calculate their sum
console.log(sum(5, 7)); // This should log the sum of 5 and 7, which is 12