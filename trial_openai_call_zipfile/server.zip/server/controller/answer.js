const express = require("express");
const Answer = require("../models/answers");
const Question = require("../models/questions");

const router = express.Router();

// Adding answer
const addAnswer = async (req, res) => {
    let answer = req.body.ans;

    const newanswer = await Answer.create({
        text: answer.text,
        ans_by: answer.ans_by,
        ans_date_time: answer.ans_date_time
    })
    await Question.findOneAndUpdate(
        {"_id": req.body.qid},
        {$push: {
        answers: {
        $each: [newanswer._id],
        $position: 0}}},
        {new: true}
        );
    res.json(newanswer);
};

router.post('/addAnswer', addAnswer);
// add appropriate HTTP verbs and their endpoints to the router.

module.exports = router;
