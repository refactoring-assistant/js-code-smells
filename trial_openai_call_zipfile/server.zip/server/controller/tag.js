const express = require("express");
const Tag = require("../models/tags");
const Question = require("../models/questions");

const router = express.Router();

const getTagsWithQuestionNumber = async (req, res) => {
    const alltaglist = await Tag.find({}); 
    var tagcnt = []
    for(let tag in alltaglist) {
        tagcnt.push({name: alltaglist[tag].name, qcnt: 0});
    }
    const qlist = await Question.find({}).populate('tags');
    for(let ques of qlist) {
        for (let qtag of ques.tags) {
            let tagobject = tagcnt.find(obj => obj.name === qtag.name);
            tagobject.qcnt++;
        }
    }
    res.json(tagcnt);
};

router.get("/getTagsWithQuestionNumber", getTagsWithQuestionNumber)
// add appropriate HTTP verbs and their endpoints to the router.

module.exports = router;
