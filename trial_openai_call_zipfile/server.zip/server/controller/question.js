const express = require("express");
const Question = require("../models/questions");
const { addTag, getQuestionsByOrder, filterQuestionsBySearch } = require('../utils/question');

const router = express.Router();

// To get Questions by Filter
const getQuestionsByFilter = async (req, res) => {
    let order = "newest";
    let search = "";
    if(req.query.order) {
        order = req.query.order;
    }
    if(req.query.search) {
        search = req.query.search;
    }
    let qlist = await getQuestionsByOrder(order);
    let newqlist = await filterQuestionsBySearch(qlist, search);
    res.json(newqlist);
};

// To get Questions by Id
const getQuestionById = async (req, res) => {
    let question = await Question.findOneAndUpdate(
        {"_id": req.params.qid},
        {$inc: {views: 1}},
        {new: true}
        );
    let newquestion = await question.populate({path: 'answers', options: {sort: {"ans_date_time": -1}}});
    console.log(newquestion);
    res.json(newquestion);
};

// To add Question
const addQuestion = async (req, res) => {
    let question = req.body;
    let tags = question.tags;
    let newtags = []
    for(let tag of tags) {
        let newtag = await addTag(tag);
        newtags.push(newtag);
    }
    question.tags = newtags;
    let newquestion = await Question.create(question);
    res.json(newquestion);
};

router.get('/getQuestion', getQuestionsByFilter);
router.get('/getQuestionById/:qid', getQuestionById)
router.post('/addQuestion', addQuestion);
// add appropriate HTTP verbs and their endpoints to the router

module.exports = router;
