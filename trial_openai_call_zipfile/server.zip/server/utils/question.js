const Tag = require("../models/tags");
const Question = require("../models/questions");

const addTag = async (tname) => {
    const reqtag = await Tag.findOne({name: tname});
    if(reqtag) {
        return reqtag._id;
    }
    const newtag = await new Tag({
        name: tname
    });
    const finaltag = await newtag.save();
    return finaltag._id;
};

const getQuestionsByOrder = async (order) => {
    const qlist = await Question.find({}).populate({path: 'answers', options: {sort: {"ans_date_time": -1}}}).populate('tags');
    let newqlist = []
    if (order == "active") {
        newqlist = getActiveQuestion(qlist);
    } else if (order == "unanswered") {
        newqlist = getUnansweredQuestion(qlist);
    } else {
        newqlist = getNewestQuestion(qlist);
    }
    return(newqlist);
    // complete the function
}

const filterQuestionsBySearch = (qlist, search) => {
    let searchTags = parseTags(search);
    let searchKeyword = parseKeyword(search);
    const res = qlist.filter((q) => {
        if (searchKeyword.length == 0 && searchTags.length == 0) {
            return true;
        } else if (searchKeyword.length == 0) {
            return checkTagInQuestion(q, searchTags);
        } else if (searchTags.length == 0) {
            return checkKeywordInQuestion(q, searchKeyword);
        } else {
            return (
                checkKeywordInQuestion(q, searchKeyword) ||
                checkTagInQuestion(q, searchTags)
            );
        }
    });
    return res;
    // complete the function return [];
}

const checkKeywordInQuestion = (q, keywordlist) => {
    for (let w of keywordlist) {
        if (q.title.toLowerCase().includes(w.toLowerCase()) || q.text.toLowerCase().includes(w.toLowerCase())) {
            return true;
        }
    }

    return false;
};

const checkTagInQuestion = (q, taglist) => {
    for (let tag of taglist) {
        for (let qtag of q.tags) {
            if (qtag.name == tag) {
                return true;
            }
        }
    }

    return false;
};

const parseTags = (search) => {
    return (search.match(/\[([^\]]+)\]/g) || []).map((word) =>
        word.slice(1, -1)
    );
};

const parseKeyword = (search) => {
    return search.replace(/\[([^\]]+)\]/g, " ").match(/\b\w+\b/g) || [];
};

const getNewestQuestion = (qlist) => {
    return qlist.sort((a, b) => {
        if (a.ask_date_time > b.ask_date_time) {
            return -1;
        } else if (a.ask_date_time < b.ask_date_time) {
            return 1;
        } else {
            return 0;
        }
    });
};

const getUnansweredQuestion = (qlist) => {
    return getNewestQuestion(qlist).filter((q) => q.answers.length == 0);
};

const getActiveQuestion = (qlist) => {
      return getNewestQuestion(qlist).sort((a,b) => {
        const datesA = a.answers.map(ans => ans.ans_date_time);
        const datesB = b.answers.map(ans => ans.ans_date_time);
        const newAnsDateA = Math.max(...datesA);
        const newAnsDateB = Math.max(...datesB)
        if (!newAnsDateA) {
            return 1;
        } else if (!newAnsDateB) {
            return -1;
        }
        if (newAnsDateA > newAnsDateB) {
            return -1;
        } else if (newAnsDateA < newAnsDateB) {
            return 1;
        } else {
            return 0;
        }
      })
};

module.exports = { addTag, getQuestionsByOrder, filterQuestionsBySearch };